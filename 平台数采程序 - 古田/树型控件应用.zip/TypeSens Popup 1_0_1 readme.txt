Type Sensitive Popup V1.0.1

Copyright � 2007, David Saunders
All rights reserved.

Author:
David Saunders
daudsaunders <at> yahoo.com

Distribution:
This code was downloaded from the LAVA Code Repository: http://forums.lavag.org/downloads.html

Description:
Provides an intuitive interface for tabular controls containing multiple data types.  Users can use various controls and datatypes.  Users can also use provided functions for registering and looking up type parameters by control (as well as by column, row, or cell).

When you click on a cell, a correctly positioned and sized popup appears allowing for a controlled and intuitive input.  Appears like it is a built-in feature, not an annoying popup window.

Features:
- Supports tables, listboxes, multicolumn listboxes, trees, and string controls.
- Implements many data types : string, integer, float, color, ring, boolean, captioned string, etc.
- Can use multiple tabular controls in same program with no programming changes
- Can pre-register controls with certain data types
 - Register the entire control, or columns, rows, and cells.
 - Can edit the registered data type by registering again at any time
- Allows for different font sizes
- Works even on modal windows

Instructions:
Run the Demo program to see example usage.
To recreate --
1.  Drop 'TSPopup.Popup Cluster.ctl' anywhere on your front panel.
2.  Create program logic, similar to the demo
MANDATORY elements
   a.  TSPopup.Initialize.vi  (register for the user event in your event structure)
   b.  TSPopup.Lookup.vi      (returns positioning information, looks up any registered controls)
   c.  TSPopup.Show Popup.vi  (called in a Mouse Down? event case)
   d.  an event case for the user event output from (a.)
   e.  TSPopup.Close.vi       (called at end of program)
OPTIONAL elements
   f.  TSPopup.Register.vi    (register controls with popup type parameters)
   g.  TSPopup.Update Cell String.vi   (provided to show how to change the cell string after popup is completed)
3. Bring the Popup Cluster to the front on the front panel.  Otherwise the popup will show up behind some of the other controls on your User Interface.

Limitations:
- Can't programmatically bring popup cluster to front.  Must do this manually.


Support:
If you have any problems with this code or want to suggest features:
http://forums.lavag.org/CR-Type-Sensitive-Popup-t8911.html

Change Log:
1.0.0: Initial release of the code.
1.0.1: Added another demo using dynamically changing data types in a tree
  Removed LV version specific event handling (only dealt with LV 7.1)
  Fixed bug where headers defaulted to have same type as their column/row
  Fixed cluster scanning from text
  Fixed ring to default to index 0 if string unrecognized
  Changed the background event monitor to always be hidden

License:
This code is distrubuted under the BSD License

Copyright � 2007, J. David Saunders

All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
* Neither the name of J. David Saunders nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.